Create a QR Code
"""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: libs/qrcode/lv_example_qrcode_1
  :language: c

